<?php session_start(); ?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Магазин</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Добро пожаловать в магазин</h1>
    <?php if (isset($_SESSION["user"])): ?>
      Привет, <?= $_SESSION["user"] ?> |
      <a href="logout_user.php">Выйти</a>
    <?php else: ?>
      <a href="login_user.php">Войти</a> |
      <a href="register.php">Регистрация</a>
    <?php endif; ?>
  </header>
  <div class="products">
    <?php
    include("db/connect.php");
    $res = $conn->query("SELECT * FROM products");
    while ($row = $res->fetch_assoc()) {
      echo "<div class='card'>";
      echo "<img src='uploads/{$row['image']}' width='200'><br>";
      echo "<h3>{$row['title']}</h3>";
      echo "<p>{$row['price']} тг</p>";
      if (isset($_SESSION['user'])) {
        echo "<button>Добавить в корзину</button>";
      } else {
        echo "<p><em>Войдите, чтобы купить</em></p>";
      }
      echo "</div>";
    }
    ?>
  </div>
</body>
</html>