<?php
session_start();
include("../db/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $login = $_POST["username"];
  $pass = md5($_POST["password"]);
  $sql = "SELECT * FROM users WHERE username='$login' AND password='$pass'";
  $res = $conn->query($sql);
  if ($res->num_rows > 0) {
    $_SESSION["admin"] = $login;
    header("Location: dashboard.php");
  } else {
    echo "Неверный логин или пароль";
  }
}
?>
<form method="post">
  <input name="username" placeholder="Логин"><br>
  <input type="password" name="password" placeholder="Пароль"><br>
  <button>Войти</button>
</form>