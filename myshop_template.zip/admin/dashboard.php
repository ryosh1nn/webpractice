<?php
session_start();
if (!isset($_SESSION["admin"])) { header("Location: login.php"); exit; }
include("../db/connect.php");
?>
<h2>Админ-панель</h2>
<a href="add.php">Добавить товар</a> |
<a href="logout.php">Выход</a><br><br>

<?php
$res = $conn->query("SELECT * FROM products");
while ($row = $res->fetch_assoc()) {
  echo "<div>";
  echo "<strong>{$row['title']}</strong> — {$row['price']} тг<br>";
  echo "<a href='edit.php?id={$row['id']}'>Изменить</a> | ";
  echo "<a href='delete.php?id={$row['id']}'>Удалить</a>";
  echo "</div><hr>";
}
?>