<?php
session_start();
if (!isset($_SESSION["admin"])) { header("Location: login.php"); exit; }
include("../db/connect.php");

$id = $_GET['id'];
$res = $conn->query("SELECT * FROM products WHERE id=$id");
$product = $res->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $title = $_POST["title"];
  $desc = $_POST["description"];
  $price = $_POST["price"];
  $img_sql = "";
  if ($_FILES["image"]["name"]) {
    $img_name = uniqid() . "_" . $_FILES["image"]["name"];
    move_uploaded_file($_FILES["image"]["tmp_name"], "../uploads/" . $img_name);
    $img_sql = ", image='$img_name'";
  }
  $conn->query("UPDATE products SET title='$title', description='$desc', price='$price' $img_sql WHERE id=$id");
  echo "Товар обновлён!";
  $res = $conn->query("SELECT * FROM products WHERE id=$id");
  $product = $res->fetch_assoc();
}
?>
<form method="post" enctype="multipart/form-data">
  <input name="title" value="<?= $product['title'] ?>"><br>
  <textarea name="description"><?= $product['description'] ?></textarea><br>
  <input name="price" value="<?= $product['price'] ?>"><br>
  <input type="file" name="image"><br>
  <img src="../uploads/<?= $product['image'] ?>" width="100"><br>
  <button>Обновить</button>
</form>