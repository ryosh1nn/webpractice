<?php
session_start();
if (!isset($_SESSION["admin"])) { header("Location: login.php"); exit; }
include("../db/connect.php");

$id = $_GET['id'];

if (isset($_POST["confirm"])) {
  $res = $conn->query("SELECT image FROM products WHERE id=$id");
  $row = $res->fetch_assoc();
  unlink("../uploads/" . $row["image"]); // удалить фото
  $conn->query("DELETE FROM products WHERE id=$id");
  echo "Товар удалён.";
  exit;
}
?>
<form method="post">
  <p>Вы уверены, что хотите удалить товар #<?= $id ?>?</p>
  <button name="confirm">Да, удалить</button>
</form>