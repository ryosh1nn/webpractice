<?php
session_start();
if (!isset($_SESSION["admin"])) { header("Location: login.php"); exit; }
include("../db/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $title = $_POST["title"];
  $desc = $_POST["description"];
  $price = $_POST["price"];
  $img_name = uniqid() . "_" . $_FILES["image"]["name"];
  move_uploaded_file($_FILES["image"]["tmp_name"], "../uploads/" . $img_name);
  $conn->query("INSERT INTO products (title, description, price, image) 
                VALUES ('$title', '$desc', '$price', '$img_name')");
  echo "Товар добавлен!";
}
?>
<form method="post" enctype="multipart/form-data">
  <input name="title" placeholder="Название"><br>
  <textarea name="description" placeholder="Описание"></textarea><br>
  <input name="price" placeholder="Цена"><br>
  <input type="file" name="image"><br>
  <button>Добавить</button>
</form>