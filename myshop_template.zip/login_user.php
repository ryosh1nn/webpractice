<?php
session_start();
include("db/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST["username"];
  $password = md5($_POST["password"]);
  $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
  $res = $conn->query($sql);
  if ($res->num_rows > 0) {
    $_SESSION["user"] = $username;
    header("Location: index.php");
  } else {
    echo "Неверный логин или пароль";
  }
}
?>
<form method="post">
  <h2>Вход пользователя</h2>
  <input name="username" placeholder="Логин"><br>
  <input type="password" name="password" placeholder="Пароль"><br>
  <button>Войти</button>
</form>