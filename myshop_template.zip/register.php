<?php
include("db/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST["username"];
  $password = md5($_POST["password"]);
  $conn->query("INSERT INTO users (username, password, role) VALUES ('$username', '$password', 'user')");
  echo "Регистрация успешна. <a href='login_user.php'>Войти</a>";
}
?>
<form method="post">
  <h2>Регистрация</h2>
  <input name="username" placeholder="Логин"><br>
  <input type="password" name="password" placeholder="Пароль"><br>
  <button>Зарегистрироваться</button>
</form>